import React from 'react'
import LoginControl from './LoginControl.jsx'

function App(props) {
  return (
    <div>
      <LoginControl />
    </div>
  )
}

export default App